# Notation Consistency Report

**Generated**: 2025-11-05 17:02:53

---

## SUMMARY

- **Total Symbols**: 2476
- **Unique Symbols**: 149
- **Issues Found**: 108
  - Inconsistencies: 29
  - Undefined/Rare: 79

## NOTATION DICTIONARY

| Symbol | First Occurrence | Usage Count |
|--------|------------------|-------------|
| B | 06_pso_optimization.md:54 | 2 |
| C | 07_simulation_setup.md:1 | 2 |
| D | 04_sliding_mode_control.md:252 | 6 |
| F | 06_pso_optimization.md:54 | 1 |
| G | 07_simulation_setup.md:1 | 2 |
| H | 06_pso_optimization.md:54 | 3 |
| H_k | 06_pso_optimization.md:54 | 1 |
| H_k^mathsfT | 06_pso_optimization.md:54 | 1 |
| J | 07_simulation_setup.md:7 | 1 |
| J_1 | 07_simulation_setup.md:1 | 1 |
| J_2 | 07_simulation_setup.md:1 | 1 |
| K | 02_literature_review.md:29 | 37 |
| K^* | 04_sliding_mode_control.md:190 | 4 |
| K_1 | 04_sliding_mode_control.md:146 | 2 |
| K_2 | 04_sliding_mode_control.md:132 | 6 |
| K_k | 06_pso_optimization.md:54 | 1 |
| K_mathrminit | 04_sliding_mode_control.md:190 | 4 |
| L | 04_sliding_mode_control.md:140 | 2 |
| M | 07_simulation_setup.md:1 | 2 |
| N | 07_simulation_setup.md:1 | 2 |
| N_dotu | 06_pso_optimization.md:54 | 1 |
| N_e | 06_pso_optimization.md:54 | 1 |
| N_sigma | 06_pso_optimization.md:54 | 1 |
| N_u | 06_pso_optimization.md:54 | 1 |
| P_k|k - 1 | 06_pso_optimization.md:54 | 1 |
| P_penalty | 06_pso_optimization.md:54 | 1 |
| P_textpenalty | 07_simulation_setup.md:7 | 1 |
| R_k | 06_pso_optimization.md:54 | 1 |
| S_k | 06_pso_optimization.md:54 | 2 |
| V | 04_sliding_mode_control.md:63 | 32 |
| V_mathrmreset | 04_sliding_mode_control.md:252 | 2 |
| a | 02_literature_review.md:19 | 230 |
| a_1 | 04_sliding_mode_control.md:240 | 12 |
| a_2 | 04_sliding_mode_control.md:240 | 11 |
| a_i | 06_pso_optimization.md:1 | 1 |
| alpha | 02_literature_review.md:35 | 13 |
| alpha_1 | 04_sliding_mode_control.md:244 | 6 |
| alpha_2 | 04_sliding_mode_control.md:244 | 2 |
| b | 04_sliding_mode_control.md:71 | 78 |
| bar | 04_sliding_mode_control.md:75 | 10 |
| beta | 04_sliding_mode_control.md:71 | 24 |
| c | 04_sliding_mode_control.md:63 | 47 |
| c_1 | 04_sliding_mode_control.md:140 | 5 |
| c_2 | 04_sliding_mode_control.md:140 | 5 |
| d | 02_literature_review.md:19 | 99 |
| d_1 | 07_simulation_setup.md:1 | 1 |
| d_2 | 07_simulation_setup.md:1 | 1 |
| d_u | 04_sliding_mode_control.md:71 | 4 |
| d_z | 02_literature_review.md:93 | 1 |
| ddot | 07_simulation_setup.md:3 | 1 |
| dot | 02_literature_review.md:19 | 45 |
| e | 02_literature_review.md:19 | 134 |
| e^-alpha_1 | 04_sliding_mode_control.md:252 | 4 |
| epsilon | 04_sliding_mode_control.md:87 | 19 |
| epsilon_eff | 06_pso_optimization.md:9 | 4 |
| epsilon_min | 06_pso_optimization.md:9 | 7 |
| eta | 04_sliding_mode_control.md:81 | 2 |
| f | 04_sliding_mode_control.md:63 | 63 |
| forall | 04_sliding_mode_control.md:81 | 2 |
| g | 02_literature_review.md:27 | 59 |
| gamma | 04_sliding_mode_control.md:182 | 10 |
| gamma_1 | 04_sliding_mode_control.md:240 | 2 |
| gamma_2 | 04_sliding_mode_control.md:240 | 2 |
| geq | 06_pso_optimization.md:9 | 1 |
| h | 02_literature_review.md:19 | 70 |
| i | 02_literature_review.md:19 | 109 |
| in | 06_pso_optimization.md:15 | 8 |
| k | 06_pso_optimization.md:54 | 21 |
| k^top | 07_simulation_setup.md:7 | 1 |
| k_1 | 02_literature_review.md:27 | 10 |
| k_1^* | 04_sliding_mode_control.md:240 | 2 |
| k_2 | 02_literature_review.md:27 | 10 |
| k_2^* | 04_sliding_mode_control.md:240 | 2 |
| k_d | 04_sliding_mode_control.md:71 | 12 |
| l | 02_literature_review.md:35 | 125 |
| l_1 | 07_simulation_setup.md:1 | 2 |
| l_2 | 07_simulation_setup.md:1 | 2 |
| lambda | 04_sliding_mode_control.md:190 | 8 |
| lambda_1 | 06_pso_optimization.md:54 | 4 |
| lambda_2 | 06_pso_optimization.md:54 | 4 |
| lbrack | 06_pso_optimization.md:54 | 5 |
| ldots | 06_pso_optimization.md:54 | 1 |
| leq | 02_literature_review.md:93 | 16 |
| limsup_t to infty | 04_sliding_mode_control.md:87 | 2 |
| m | 02_literature_review.md:27 | 108 |
| m_1 | 07_simulation_setup.md:1 | 2 |
| m_2 | 07_simulation_setup.md:1 | 2 |
| m_i=1^N_mathrmreset | 04_sliding_mode_control.md:252 | 2 |
| mathbf | 04_sliding_mode_control.md:244 | 18 |
| mathrm | 02_literature_review.md:27 | 19 |
| mathsf | 06_pso_optimization.md:54 | 1 |
| max | 07_simulation_setup.md:1 | 2 |
| min | 07_simulation_setup.md:3 | 1 |
| n | 02_literature_review.md:27 | 45 |
| n_eff | 06_pso_optimization.md:9 | 4 |
| n_min | 06_pso_optimization.md:9 | 7 |
| neq | 04_sliding_mode_control.md:81 | 2 |
| o | 02_literature_review.md:19 | 87 |
| p | 02_literature_review.md:35 | 59 |
| p_1 | 06_pso_optimization.md:54 | 1 |
| p_2 | 06_pso_optimization.md:54 | 1 |
| p_n | 06_pso_optimization.md:54 | 1 |
| p_t to infty | 04_sliding_mode_control.md:87 | 2 |
| pi | 06_pso_optimization.md:1 | 2 |
| pm | 07_simulation_setup.md:3 | 2 |
| q | 02_literature_review.md:93 | 41 |
| q_1 | 07_simulation_setup.md:1 | 7 |
| q_2 | 07_simulation_setup.md:1 | 7 |
| r | 02_literature_review.md:27 | 98 |
| rbrack | 06_pso_optimization.md:54 | 4 |
| rbrack^top | 07_simulation_setup.md:7 | 1 |
| rightarrow | 06_pso_optimization.md:1 | 3 |
| s | 02_literature_review.md:27 | 129 |
| s^2 | 04_sliding_mode_control.md:63 | 14 |
| sgn | 07_simulation_setup.md:3 | 1 |
| sigma | 02_literature_review.md:27 | 20 |
| t | 02_literature_review.md:19 | 225 |
| t_i | 04_sliding_mode_control.md:252 | 2 |
| tanh | 06_pso_optimization.md:1 | 1 |
| theta | 02_literature_review.md:19 | 5 |
| theta_1 | 06_pso_optimization.md:1 | 4 |
| theta_2 | 06_pso_optimization.md:1 | 3 |
| theta_i | 06_pso_optimization.md:1 | 1 |
| tilde | 04_sliding_mode_control.md:182 | 16 |
| top | 07_simulation_setup.md:1 | 2 |
| u | 04_sliding_mode_control.md:81 | 12 |
| u_k | 06_pso_optimization.md:54 | 1 |
| u_mathrmint | 04_sliding_mode_control.md:240 | 4 |
| u_max | 07_simulation_setup.md:1 | 2 |
| u_texteq | 07_simulation_setup.md:1 | 1 |
| u_textrobust | 07_simulation_setup.md:1 | 1 |
| v | 07_simulation_setup.md:1 | 4 |
| v_k | 06_pso_optimization.md:54 | 1 |
| varepsilon | 07_simulation_setup.md:3 | 2 |
| w | 06_pso_optimization.md:1 | 8 |
| w_dotu | 06_pso_optimization.md:54 | 2 |
| w_e | 06_pso_optimization.md:54 | 2 |
| w_k | 06_pso_optimization.md:54 | 1 |
| w_s | 07_simulation_setup.md:7 | 1 |
| w_sigma | 06_pso_optimization.md:54 | 1 |
| w_u | 06_pso_optimization.md:54 | 2 |
| x | 02_literature_review.md:93 | 19 |
| x_k | 06_pso_optimization.md:54 | 2 |
| x_k + 1 | 06_pso_optimization.md:54 | 1 |
| xi | 04_sliding_mode_control.md:140 | 2 |
| y_k | 06_pso_optimization.md:54 | 1 |
| z | 02_literature_review.md:27 | 7 |
| z^2 | 04_sliding_mode_control.md:132 | 2 |
| z_k | 06_pso_optimization.md:54 | 1 |

## ISSUES FOUND

### Notation Inconsistencies

#### theta - MEDIUM

Symbol 'theta' has 4 different notation forms

Locations:
- 02_literature_review.md:19
- 06_pso_optimization.md:1
- 06_pso_optimization.md:1
- 06_pso_optimization.md:1

#### t - MEDIUM

Symbol 't' has 2 different notation forms

Locations:
- 02_literature_review.md:19
- 04_sliding_mode_control.md:252

#### e - MEDIUM

Symbol 'e' has 2 different notation forms

Locations:
- 02_literature_review.md:19
- 04_sliding_mode_control.md:252

#### a - MEDIUM

Symbol 'a' has 4 different notation forms

Locations:
- 02_literature_review.md:19
- 04_sliding_mode_control.md:240
- 04_sliding_mode_control.md:240
- 06_pso_optimization.md:1

#### d - MEDIUM

Symbol 'd' has 5 different notation forms

Locations:
- 02_literature_review.md:19
- 02_literature_review.md:93
- 04_sliding_mode_control.md:71
- 07_simulation_setup.md:1
- 07_simulation_setup.md:1

#### z - MEDIUM

Symbol 'z' has 3 different notation forms

Locations:
- 02_literature_review.md:27
- 04_sliding_mode_control.md:132
- 06_pso_optimization.md:54

#### m - MEDIUM

Symbol 'm' has 4 different notation forms

Locations:
- 02_literature_review.md:27
- 04_sliding_mode_control.md:252
- 07_simulation_setup.md:1
- 07_simulation_setup.md:1

#### s - MEDIUM

Symbol 's' has 2 different notation forms

Locations:
- 02_literature_review.md:27
- 04_sliding_mode_control.md:63

#### n - MEDIUM

Symbol 'n' has 3 different notation forms

Locations:
- 02_literature_review.md:27
- 06_pso_optimization.md:9
- 06_pso_optimization.md:9

#### k - MEDIUM

Symbol 'k' has 7 different notation forms

Locations:
- 02_literature_review.md:27
- 02_literature_review.md:27
- 04_sliding_mode_control.md:71
- 04_sliding_mode_control.md:240
- 04_sliding_mode_control.md:240
- 06_pso_optimization.md:54
- 07_simulation_setup.md:7

#### K - MEDIUM

Symbol 'K' has 6 different notation forms

Locations:
- 02_literature_review.md:29
- 04_sliding_mode_control.md:132
- 04_sliding_mode_control.md:146
- 04_sliding_mode_control.md:190
- 04_sliding_mode_control.md:190
- 06_pso_optimization.md:54

#### alpha - MEDIUM

Symbol 'alpha' has 3 different notation forms

Locations:
- 02_literature_review.md:35
- 04_sliding_mode_control.md:244
- 04_sliding_mode_control.md:244

#### l - MEDIUM

Symbol 'l' has 3 different notation forms

Locations:
- 02_literature_review.md:35
- 07_simulation_setup.md:1
- 07_simulation_setup.md:1

#### p - MEDIUM

Symbol 'p' has 5 different notation forms

Locations:
- 02_literature_review.md:35
- 04_sliding_mode_control.md:87
- 06_pso_optimization.md:54
- 06_pso_optimization.md:54
- 06_pso_optimization.md:54

#### q - MEDIUM

Symbol 'q' has 3 different notation forms

Locations:
- 02_literature_review.md:93
- 07_simulation_setup.md:1
- 07_simulation_setup.md:1

#### x - MEDIUM

Symbol 'x' has 3 different notation forms

Locations:
- 02_literature_review.md:93
- 06_pso_optimization.md:54
- 06_pso_optimization.md:54

#### V - MEDIUM

Symbol 'V' has 2 different notation forms

Locations:
- 04_sliding_mode_control.md:63
- 04_sliding_mode_control.md:252

#### c - MEDIUM

Symbol 'c' has 3 different notation forms

Locations:
- 04_sliding_mode_control.md:63
- 04_sliding_mode_control.md:140
- 04_sliding_mode_control.md:140

#### u - MEDIUM

Symbol 'u' has 6 different notation forms

Locations:
- 04_sliding_mode_control.md:81
- 04_sliding_mode_control.md:240
- 06_pso_optimization.md:54
- 07_simulation_setup.md:1
- 07_simulation_setup.md:1
- 07_simulation_setup.md:1

#### epsilon - MEDIUM

Symbol 'epsilon' has 3 different notation forms

Locations:
- 04_sliding_mode_control.md:87
- 06_pso_optimization.md:9
- 06_pso_optimization.md:9

#### gamma - MEDIUM

Symbol 'gamma' has 3 different notation forms

Locations:
- 04_sliding_mode_control.md:182
- 04_sliding_mode_control.md:240
- 04_sliding_mode_control.md:240

#### lambda - MEDIUM

Symbol 'lambda' has 3 different notation forms

Locations:
- 04_sliding_mode_control.md:190
- 06_pso_optimization.md:54
- 06_pso_optimization.md:54

#### w - MEDIUM

Symbol 'w' has 7 different notation forms

Locations:
- 06_pso_optimization.md:1
- 06_pso_optimization.md:54
- 06_pso_optimization.md:54
- 06_pso_optimization.md:54
- 06_pso_optimization.md:54
- 06_pso_optimization.md:54
- 07_simulation_setup.md:7

#### H - MEDIUM

Symbol 'H' has 3 different notation forms

Locations:
- 06_pso_optimization.md:54
- 06_pso_optimization.md:54
- 06_pso_optimization.md:54

#### v - MEDIUM

Symbol 'v' has 2 different notation forms

Locations:
- 06_pso_optimization.md:54
- 07_simulation_setup.md:1

#### P - MEDIUM

Symbol 'P' has 3 different notation forms

Locations:
- 06_pso_optimization.md:54
- 06_pso_optimization.md:54
- 07_simulation_setup.md:7

#### rbrack - MEDIUM

Symbol 'rbrack' has 2 different notation forms

Locations:
- 06_pso_optimization.md:54
- 07_simulation_setup.md:7

#### N - MEDIUM

Symbol 'N' has 5 different notation forms

Locations:
- 06_pso_optimization.md:54
- 06_pso_optimization.md:54
- 06_pso_optimization.md:54
- 06_pso_optimization.md:54
- 07_simulation_setup.md:1

#### J - MEDIUM

Symbol 'J' has 3 different notation forms

Locations:
- 07_simulation_setup.md:1
- 07_simulation_setup.md:1
- 07_simulation_setup.md:7

### Potentially Undefined Symbols

*These symbols appear only once or twice. Verify they are defined.*

| Symbol | Location |
|--------|----------|
| d_z | 02_literature_review.md:93 |
| eta | 04_sliding_mode_control.md:81 |
| forall | 04_sliding_mode_control.md:81 |
| neq | 04_sliding_mode_control.md:81 |
| limsup_t to infty | 04_sliding_mode_control.md:87 |
| p_t to infty | 04_sliding_mode_control.md:87 |
| z^2 | 04_sliding_mode_control.md:132 |
| xi | 04_sliding_mode_control.md:140 |
| L | 04_sliding_mode_control.md:140 |
| K_1 | 04_sliding_mode_control.md:146 |
| gamma_1 | 04_sliding_mode_control.md:240 |
| gamma_2 | 04_sliding_mode_control.md:240 |
| k_1^* | 04_sliding_mode_control.md:240 |
| k_2^* | 04_sliding_mode_control.md:240 |
| alpha_2 | 04_sliding_mode_control.md:244 |
| m_i=1^N_mathrmreset | 04_sliding_mode_control.md:252 |
| V_mathrmreset | 04_sliding_mode_control.md:252 |
| t_i | 04_sliding_mode_control.md:252 |
| theta_i | 06_pso_optimization.md:1 |
| pi | 06_pso_optimization.md:1 |

*... and 59 more*

---

## VALIDATION VERDICT

**STATUS**: [WARNING] REVIEW REQUIRED

Inconsistencies (29) exceed threshold (5).
Please review and standardize notation before thesis submission.
