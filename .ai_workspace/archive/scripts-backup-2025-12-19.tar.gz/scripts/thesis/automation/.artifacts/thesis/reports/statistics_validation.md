# Statistical Validation Report - Chapter 08

**Generated**: 2025-11-05 17:02:40

---

## SUMMARY

- **Total Statistical Claims**: 6
- **Validated Claims**: 6
- **Failed Claims**: 0
- **Success Rate**: 100.0%
- **Bonferroni Correction Applied**: [WARNING] NO
- **Normality Tests Mentioned**: [WARNING] NO
- **Overall Status**: **CONDITIONAL**

## STATISTICAL THRESHOLDS

- **Number of Tests**: 15 (pairwise comparisons)
- **Uncorrected Alpha**: 0.05
- **Bonferroni Corrected Alpha**: 0.00333 (α/15)
- **Minimum Effect Size**: 0.5 (Cohen's d)

## CLAIMS DETAIL

### Claim 1: PASS

**Text**: # Results and Discussion This chapter analyses the **particle‑swarm‑optimisation (PSO)** tuning of s...

**95% CI**: [1.0, 2.0]

**Location**: Line 1

---

### Claim 2: PASS

**Text**: - **Hybrid adaptive–STA** – combines the STA with adaptive gain tuning. Two gains k1(t)k_{1}(t) and ...

**Effect Size**: 0.5 (medium)

**95% CI**: [4.0, 9.0]

**Location**: Line 5

---

### Claim 3: PASS

**Text**: - True relative performance ranking can only be established after equal optimization effort ##### 8....

**95% CI**: [3.0, 4.0]

**Location**: Line 29

---

### Claim 4: PASS

**Text**: Second, the fitness function should incorporate explicit robustness constraints. The MT-6 cost funct...

**95% CI**: [8.0, 11.0]

**Location**: Line 76

---

### Claim 5: PASS

**Text**: --- #### 8.5 Discussion and interpretation ##### 8.5.1 Synthesis of findings The PSO tuner identifie...

**95% CI**: [10.0, 11.0]

**Location**: Line 104

---

### Claim 6: PASS

**Text**: First, **multi-scenario PSO optimization** is essential to prevent parameter overfitting. The 50.4x ...

**95% CI**: [8.0, 11.0]

**Location**: Line 108

---

## VALIDATION VERDICT

**STATUS**: [WARNING] CONDITIONAL PASS

Most claims validated, but some issues found. Manual review recommended.
