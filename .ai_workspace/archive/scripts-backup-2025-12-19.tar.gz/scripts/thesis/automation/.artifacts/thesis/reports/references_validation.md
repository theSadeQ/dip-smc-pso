# Cross-Reference Validation Report

**Generated**: 2025-11-05 17:01:44

---

## SUMMARY

- **Total References**: 128
- **Valid References**: 65
- **Broken References**: 63
- **Success Rate**: 50.8%

## TARGETS FOUND

- **Equation**: 0 targets
- **Figure**: 1 targets
- **Table**: 128 targets

## BROKEN REFERENCES (REQUIRES REVIEW)

| Type | Reference | File | Line | Context |
|------|-----------|------|------|---------|
| section | Section 1 | 03_system_modeling.md | 1 | .yaml`. ------ ## **Section 1: System Dynamics an... |
| table | Table 1.1 | 03_system_modeling.md | 7 | ## **Nomenclature** Table 1.1 summarises the symb... |
| table | Table 1.2 | 03_system_modeling.md | 22 | /dynamics_full.py`. Table 1.2 maps key terms in t... |
| section | Section 1.4 | 03_system_modeling.md | 31 | duct terms shown in Section 1.4; for example, C23=... |
| section | Section 1.3 | 03_system_modeling.md | 31 | side terms used in Section 1.3. ### **1.7 Model Si... |
| figure | Figure 4.1 | 04_sliding_mode_control.md | 45 | the sign function. Figure 4.1 plots the ideal sig... |
| figure | Figure 4.1 | 04_sliding_mode_control.md | 49 | *Figure 4.1 – Approximation of... |
| section | Section 2 | 05_chattering_mitigation.md | 11 | reduce chattering. Section 2 derives the equatio... |
| section | Section 3 | 05_chattering_mitigation.md | 11 | control objective; Section 3 describes the simul... |
| section | Section 8 | 05_chattering_mitigation.md | 11 | controller in turn; Section 8 presents a quantita... |
| section | Section 9 | 05_chattering_mitigation.md | 11 | uency analysis; and Section 9 summarises the find... |
| figure | Figure 5.1 | 05_chattering_mitigation.md | 87 | Figure 5.1 presents the contro... |
| figure | Figure 5.2 | 05_chattering_mitigation.md | 87 | stic of chattering. Figure 5.2 shows the correspon... |
| section | Section 3. | 05_chattering_mitigation.md | 87 | lation described in Section 3.... |
| figure | Figure 5.1 | 05_chattering_mitigation.md | 91 | **Figure 5.1:** Control input \\... |
| figure | Figure 5.2 | 05_chattering_mitigation.md | 95 | **Figure 5.2:** Sliding variable... |
| section | Section 4. | 05_chattering_mitigation.md | 99 | function defined in Section 4. Inside a boundary l... |
| figure | Figure 5.3 | 05_chattering_mitigation.md | 120 | Figure 5.3 compares the contro... |
| figure | Figure 5.3 | 05_chattering_mitigation.md | 124 | **Figure 5.3:** Overlay of contr... |
| figure | Figure 5.4 | 05_chattering_mitigation.md | 142 | Figure 5.4 illustrates how the... |
| figure | Figure 5.5 | 05_chattering_mitigation.md | 142 | he sliding surface. Figure 5.5 shows the correspon... |
| figure | Figure 5.4 | 05_chattering_mitigation.md | 146 | **Figure 5.4:** Evolution of the... |
| figure | Figure 5.5 | 05_chattering_mitigation.md | 150 | **Figure 5.5:** Sliding variable... |
| figure | Figure 5.5 | 05_chattering_mitigation.md | 177 | Fourier transform. Figure 5.5.6 plots the magnitu... |
| figure | Figure 5.5 | 05_chattering_mitigation.md | 181 | **Figure 5.5.6:** Discrete Fouri... |
| section | Section 5 | 06_pso_optimization.md | 54 | tions in the plane. Section 5 presents the result... |
| figure | Figure 6.1 | 06_pso_optimization.md | 59 | line classical SMC. Figure 6.1 shows initial angle... |
| figure | Figure 6.2 | 06_pso_optimization.md | 59 | d frequency 0.1 Hz. Figure 6.2 plots the pendulum... |
| figure | Figure 6.3 | 06_pso_optimization.md | 59 | stribution shown in Figure 6.3. The histogram indi... |
| section | Section 6 | 06_pso_optimization.md | 59 | esults discussed in Section 6 summarise the findi... |
| figure | Figure 7.1 | 07_simulation_setup.md | 9 | e the search space. Figure 7.1 shows the cost vers... |
| figure | Figure 7.1 | 07_simulation_setup.md | 9 | ce over iterations *Figure 7.1 – PSO convergence h... |
| figure | Figure 7.2 | 07_simulation_setup.md | 9 | simulated for 10 s. Figure 7.2 illustrates the car... |
| figure | Figure 7.2 | 07_simulation_setup.md | 9 | SO‑tuned SMC gains *Figure 7.2 – System response u... |
| section | Section 8.4 | 08_results.md | 17 | ns. As discussed in Section 8.4.5, the generalizat... |
| chapter | Chapter 5 | 08_results.md | 17 | lations reported in Chapter 5. The metrics includ... |
| chapter | Chapter 6 | 08_results.md | 29 | not performed, but Chapter 6 outlines procedures... |
| section | Section 8.2 | 08_results.md | 110 | ary-layer approach (Section 8.2.5) provides a foun... |
| chapter | Chapter 6 | 08_results.md | 116 | operating envelope. Chapter 6 outlines procedures... |
| chapter | Chapter 4 | 09_conclusion.md | 87 | Chapter 4 now includes a cros... |
| chapter | Chapter 8 | 09_conclusion.md | 124 | seline simulations (Chapter 8) revealed the follo... |
| chapter | Chapter 4 | 09_conclusion.md | 167 | equirements matrix (Chapter 4) provides a practic... |
| section | Section 4 | appendix_a_proofs.md | 3 | tions in Chapter 4 (Section 4, Cross-Controller S... |
| chapter | Chapter 4 | appendix_a_proofs.md | 3 | ry presentations in Chapter 4 (Section 4, Cross-C... |
| chapter | Chapter 4 | appendix_a_proofs.md | 5 | Cross-references to Chapter 4 and implementation... |
| section | Section 4.1 | appendix_a_proofs.md | 22 | rence:** Chapter 4, Section 4.1 (Classical SMC)... |
| chapter | Chapter 4 | appendix_a_proofs.md | 22 | **Reference:** Chapter 4, Section 4.1 (Class... |
| equation | Equation 3.15 | appendix_a_proofs.md | 51 | ynamics (Chapter 3, Equation 3.15):... |
| chapter | Chapter 3 | appendix_a_proofs.md | 51 | m the DIP dynamics (Chapter 3, Equation 3.15):... |
| chapter | Chapter 3 | appendix_a_proofs.md | 63 | B > 0 (verified in Chapter 3) ensures that the s... |
| section | Section 4.2 | appendix_a_proofs.md | 91 | rence:** Chapter 4, Section 4.2 (Super-Twisting SM... |
| chapter | Chapter 4 | appendix_a_proofs.md | 91 | **Reference:** Chapter 4, Section 4.2 (Super... |
| section | Section 4.3 | appendix_a_proofs.md | 165 | rence:** Chapter 4, Section 4.3 (Adaptive SMC)... |
| chapter | Chapter 4 | appendix_a_proofs.md | 165 | **Reference:** Chapter 4, Section 4.3 (Adapt... |
| section | Section 4.4 | appendix_a_proofs.md | 236 | rence:** Chapter 4, Section 4.4 (Hybrid Adaptive-S... |
| chapter | Chapter 4 | appendix_a_proofs.md | 236 | **Reference:** Chapter 4, Section 4.4 (Hybri... |
| section | Section 4.5 | appendix_a_proofs.md | 298 | rence:** Chapter 4, Section 4.5 (Swing-Up SMC)... |
| chapter | Chapter 4 | appendix_a_proofs.md | 298 | **Reference:** Chapter 4, Section 4.5 (Swing... |
| section | Section 4.5 | appendix_a_proofs.md | 349 | rence:** Chapter 4, Section 4.5 (Variant V: MPC)... |
| chapter | Chapter 4 | appendix_a_proofs.md | 349 | **Reference:** Chapter 4, Section 4.5 (Varia... |
| chapter | Chapter 4 | appendix_a_proofs.md | 428 | *Cross-Reference:** Chapter 4, Table 4.1 (Cross-C... |
| chapter | Chapter 4 | appendix_a_proofs.md | 452 | ecks implemented in Chapter 4, Validation Require... |
| chapter | Chapter 8 | appendix_a_proofs.md | 453 | imental validation: Chapter 8 (Results and Discus... |

---

## VALIDATION VERDICT

**STATUS**: [ERROR] FAIL

Broken references (63) exceed threshold (0).
Please review and fix broken references before thesis submission.
