# benchmarks.__init__

**Source:** `src\benchmarks\__init__.py`

## Module Overview

*No module docstring available.*

## Complete Source Code

```{literalinclude} ../../../src/benchmarks/__init__.py
:language: python
:linenos:
```


