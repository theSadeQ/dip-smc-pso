# Controller API Reference > **Note:** Controller API documentation has been consolidated into references. ## Quick Links - **[Factory System API](factory_system_api_reference.md)** - Complete factory and controller creation API

- **[Base Controller Interface](../reference/controllers/base_controller_interface.md)** - Controller interface specifications
- **[SMC Algorithms](../reference/controllers/)** - Individual SMC variant APIs ## Controller Types ### Classical SMC
- **[Classical SMC API](../reference/controllers/smc_algorithms_classical_controller.md)**
- **[Technical Guide](../controllers/classical_smc_technical_guide.md)** ### Super-Twisting SMC
- **[STA SMC API](../reference/controllers/smc_algorithms_super_twisting_controller.md)**
- **[Technical Guide](../controllers/sta_smc_technical_guide.md)** ### Adaptive SMC
- **[Adaptive SMC API](../reference/controllers/smc_algorithms_adaptive_controller.md)**
- **[Technical Guide](../controllers/adaptive_smc_technical_guide.md)** ### Hybrid Adaptive STA-SMC
- **[Hybrid SMC API](../reference/controllers/smc_algorithms_hybrid_controller.md)**
- **[Technical Guide](../controllers/hybrid_smc_technical_guide.md)**

---

**Redirect:** See factory_system_api_reference.md for complete controller API documentation
