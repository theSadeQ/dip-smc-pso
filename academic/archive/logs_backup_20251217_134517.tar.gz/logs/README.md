# .logs/ - System and Application Logs

**Purpose:** Centralized logging for tests, monitoring, and runtime data

**Created:** December 17, 2025
**Location:** Hidden directory (reduces visible root clutter)

---

## Directory Structure

### test_core_validation.log
Pytest test execution logs (220KB)
- Contains test run outputs
- Updated on each test execution
- Size should remain <1MB

### monitoring/
Runtime monitoring system logs and data (48KB + structured data)
- `index.db` - SQLite database (48KB)
- `README.md` - Monitoring system documentation (15KB)
- `live/` - Live monitoring JSON files
- `logs/` - Monitoring system logs (alerts.log, data_manager logs)
- `pso_runs/` - PSO optimization run data (356KB, 2 JSON files)
- `runs/` - 5 timestamped simulation run directories

### monitoring_data_merged/
Merged monitoring data from root-level monitoring_data/ directory (56MB)
- Contains historical data_manager logs
- Consolidated during workspace cleanup (Dec 17, 2025)

### pso_*.log
PSO optimization logs (timestamped)
- Format: `pso_YYYYMMDD.log`
- Contains PSO convergence data, particle positions, fitness evaluations
- Example: `pso_20251217.log` (moved from root report.log)

---

## Log Rotation Policy

### When to Rotate
- Individual logs >10MB should be archived
- Test logs >5MB should be compressed
- Monitoring system manages its own logs automatically

### How to Archive
```bash
# Create archive directory
mkdir -p .logs/archive/YYYY-MM

# Move old logs
mv .logs/pso_202512*.log .logs/archive/2025-12/
gzip .logs/archive/2025-12/*.log

# Verify size reduction
du -sh .logs/
```

### Retention Policy
- Test logs: Keep last 30 days
- PSO logs: Keep last 90 days
- Monitoring logs: System manages rotation
- Archives: Review quarterly, delete >1 year old

---

## Size Guidelines

**Target:** <100MB total for .logs/

**Current Breakdown:**
- monitoring_data_merged/: ~56MB (historical data)
- test_core_validation.log: 220KB
- monitoring/: ~48KB (index.db) + structured data
- pso logs: Variable (typically <1MB each)

**Cleanup Actions:**
- Archive monitoring_data_merged/ logs >90 days old
- Compress old PSO logs
- Rotate test logs monthly

---

## Integration with Scripts

### Writing Logs
Scripts should write to .logs/ subdirectories:
```python
# Good - writes to .logs/
log_file = Path(".logs") / f"pso_{datetime.now().strftime('%Y%m%d')}.log"

# Bad - writes to root
log_file = "report.log"
```

### Reading Logs
```python
from pathlib import Path

# Find most recent PSO log
log_dir = Path(".logs")
pso_logs = sorted(log_dir.glob("pso_*.log"), reverse=True)
latest_log = pso_logs[0] if pso_logs else None
```

---

## Troubleshooting

### "Cannot find .logs/ directory"
- Directory is hidden (starts with dot)
- On Windows: Use `ls -la` or enable "Show hidden files"
- Verify: `test -d .logs && echo "exists" || echo "missing"`

### "Monitoring system not writing logs"
- Check `.logs/monitoring/logs/` for recent files
- Verify monitoring system configuration
- Check file permissions: `.logs/` should be writable

### "Logs growing too large"
- Review .logs/ size: `du -sh .logs/`
- Identify largest files: `du -sh .logs/* | sort -rh | head -10`
- Archive or compress old logs

---

## Maintenance Tasks

### Weekly
- Check total .logs/ size: `du -sh .logs/`
- Verify no logs >10MB: `find .logs -name "*.log" -size +10M`

### Monthly
- Archive test logs >30 days old
- Compress PSO logs >90 days old
- Review monitoring_data_merged/ for archival candidates

### Quarterly
- Delete archived logs >1 year old
- Review retention policy effectiveness
- Update this README if structure changes

---

**Last Updated:** December 17, 2025
**Workspace Organization:** Professional grade structure (CLAUDE.md compliant)
**Hidden Directory Justification:** Reduces visible root items, centralizes logging
