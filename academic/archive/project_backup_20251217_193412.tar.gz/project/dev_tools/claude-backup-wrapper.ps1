# Wrapper script that sets working directory before running backup
Set-Location "D:\Projects\main"
& "D:\Projects\main\.dev_tools\claude-backup.ps1"
