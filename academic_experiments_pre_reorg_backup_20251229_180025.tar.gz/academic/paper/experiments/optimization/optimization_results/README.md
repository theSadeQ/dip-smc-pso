# PSO Optimization Results

Organized repository of PSO-tuned controller gains, analysis results, and experimental archives.

## Directory Structure

- `active/` - Current working results (MT-8 reproducibility, test panels)
- `phases/` - Phase-organized gains (Phase 2: comprehensive benchmark, Phase 53: Lyapunov)
- `analysis_results/` - Comparison JSONs and summary statistics
- `archive/` - Historical/deprecated gains (2024-10, robust variants)

**Note:** PSO logs moved to `.logs/pso/` for centralized logging (Dec 19, 2025 migration)

## Gains Naming Convention

**Standard Format:**
```json
{
  "controller": "Classical SMC",
  "type": "classical_smc",
  "gains": [23.67, 14.29, 8.87, 3.55, 6.52, 2.93],
  "cost": 0.0,
  "iterations": 150,
  "timestamp": 1765381865.16
}
```

**File Naming:** `{controller}_{variant}_gains.json`
- Example: `adaptive_smc_robust_gains.json`
- Phase-specific: `optimized_gains_{controller}_phase53.json`
- Test-specific: `mt8_repro_seed42_{controller}.json`

## PSO Logs Location

**Migrated to `.logs/pso/`** (Dec 19, 2025):
- Root logs: `.logs/pso/2025-12-09_*.log`
- Phase2 logs: `.logs/pso/phase2/2025-12-08_*.log`
- Total: 13 logs, 978 KB

See `.logs/README.md` for retention policy.

## Usage Examples

**Load gains (Python):**
```python
import json
from pathlib import Path

# Load active MT-8 baseline
with open('optimization_results/active/mt8_baseline_gains.json') as f:
    gains = json.load(f)

# Load Phase 53 Lyapunov-optimized gains
with open('optimization_results/phases/phase53/optimized_gains_adaptive_smc_phase53.json') as f:
    lyapunov_gains = json.load(f)
```

**Load gains (CLI):**
```bash
# Use with simulate.py
python simulate.py --ctrl classical_smc \
  --load optimization_results/active/mt8_baseline_gains.json --plot
```

## Research Task References

- **Phase 2** (Oct 2025): Comprehensive benchmark (7 controllers)
  - Gains: `phases/phase2/gains/{standard,robust}/`
  - Analysis: `analysis_results/phase2_summary.json`
- **Phase 5.3** (Nov 2025): Lyapunov optimization
  - Gains: `phases/phase53/optimized_gains_*_phase53.json`
- **MT-8** (Oct 29, 2025): Disturbance rejection testing
  - Baseline: `active/mt8_baseline_gains.json`
  - Reproducibility: `active/mt8_repro_seed42_*.json`

## Migration History

### December 19, 2025: Restructuring
- Moved 13 PSO logs (978 KB) → `.logs/pso/`
- Organized gains: active/, phases/, analysis_results/, archive/
- Removed empty directories: analysis/, comparisons/
- Created this README for documentation

**Result:** Clean structure - 0 loose files at root, 4 organized subdirectories
